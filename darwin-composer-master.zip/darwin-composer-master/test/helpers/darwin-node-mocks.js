jest.mock('debug', () => {
  return function () {
    return jest.fn();
  };
});
jest.mock('request-context', () => {
  return {
    middleware: jest.fn()
  };
});
jest.mock('express', () => {
  return function () {
    return {
      use: jest.fn(),
      get: jest.fn()
    };
  };
});
jest.mock('@darwin-node/express-security', () => {
  return {
    init: jest.fn()
  };
});
jest.mock('@darwin-node/middlewares', () => {
  return {
    reqCntxMiddleware: jest.fn(),
    overrideResponse: jest.fn(),
    headersPropagation: {
      init: jest.fn()
    }
  };
});
jest.mock('@darwin-node/logger', () => {
  return {
    actLog: {
      info: jest.fn(),
      error: jest.fn(),
      debug: jest.fn()
    },
    funcLog: {
      info: jest.fn(),
      error: jest.fn(),
      debug: jest.fn()
    },
    techLog: {
      info: jest.fn(),
      error: jest.fn(),
      debug: jest.fn()
    }
  };
});
