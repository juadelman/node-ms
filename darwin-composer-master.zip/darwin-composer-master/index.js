const { generate } = require('./lib');
module.exports = {
  generate
};
