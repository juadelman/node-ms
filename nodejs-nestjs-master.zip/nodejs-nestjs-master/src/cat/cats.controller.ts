import { Controller, Get, HttpCode, Req, Post, Redirect, Body, HttpStatus, HttpException } from '@nestjs/common';
import { techLog } from 'darwin-logger';
import { CreateCatDto } from './dto/cat.dto';
import { CatService } from './cat.service';
import { Cat } from './interfaces/cat.interface';

@Controller('cats')
export class CatController {
    constructor(private readonly catsService: CatService) {};
    
    @Get('error')
    getErro(): any {
      throw new HttpException('Forbidden', HttpStatus.FORBIDDEN);
    }

    @Get()
    async findAll(): Promise<Cat[]> {
      return this.catsService.findAll();
    }

    @Get('sick')
    @HttpCode(200)
    findAllSick(): Array<String> {
      techLog.info('find all sick cats');
      return ['sick cat 1', 'sick cat 2'];
    }

    @Get('strong')
    findAllStrong(@Req() request): any {
      return ['strong cat 1'].concat(Object.values(request.query));
    }

    @Post()
    async create(@Body() createCatDto: CreateCatDto) {
      this.catsService.create(createCatDto);
    }
    
    @Get('redirect')
    @Redirect('https://sosfelinos.org/', 301)
    getRedirect(): any {
      return { url: 'https://sosfelinos.org/' };
    }
}