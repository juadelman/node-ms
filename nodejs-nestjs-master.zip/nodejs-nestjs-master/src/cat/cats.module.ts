import { Module, Global } from "@nestjs/common";
import { CatController } from './cats.controller';
import { CatService } from "./cat.service";

@Global()
@Module({
  controllers: [CatController],
  providers: [CatService],
  exports:[CatsModule]
})
export class CatsModule {}