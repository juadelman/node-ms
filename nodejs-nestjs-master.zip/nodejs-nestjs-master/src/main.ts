import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
// import middleware = require('darwin-express-security');
// const contextService = require('request-context');

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  // wrap requests in the 'request' namespace (can be any string)
  // app.use(contextService.middleware('request'));
  // app.use(middleware);
  await app.listen(3000);
}
bootstrap();
