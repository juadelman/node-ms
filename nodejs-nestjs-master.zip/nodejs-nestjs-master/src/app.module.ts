import { Module, NestModule, RequestMethod } from '@nestjs/common';
import { CatsModule } from './cat/cats.module';
import { LoggerMiddleware } from './common/middleware/logger.middleware';
import { CatController } from './cat/cats.controller';


@Module({
  imports: [CatsModule]
})
export class AppModule implements NestModule {
  configure(consumer: import("@nestjs/common").MiddlewareConsumer) {
    consumer
      .apply(LoggerMiddleware)
      // .forRoutes({ path: '*', method: RequestMethod.ALL });
      .exclude(
        { path: 'cats', method: RequestMethod.GET }
      )
      .forRoutes(CatController);
  }
  
}
