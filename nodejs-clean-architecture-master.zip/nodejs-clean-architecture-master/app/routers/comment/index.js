const express = require('express');
const { commentController } = require('../../controllers');
const router = express.Router();

router.route('/')
  .post(commentController.postComent);

module.exports = router;
