const commentRouter = require('./comment');
const express = require('express');
const router = express.Router();

router.use('/api/comment', commentRouter);

module.exports = router;
