const prefix = '/api/poc';
module.exports = {
  security: {
    enable: false,
    exclude: [
      `${prefix}/cats/:catId([0-9]{6})`,
      `${prefix}/error`,
      `${prefix}/public/mapping/string/only`,
      /\/api\/poc\/domain\/.*\/cancel/,
      { path: `${prefix}/only/put`, method: 'PUT' }
    ],
    keyProviderType: {
      remote: {
        url: 'https://apisistema-san-servicios-comunes-dev.appls.boaw.paas.gsnetcloud.corp/pkm/v1/publicKey/'
      }
    },
    headers: {
      propagation: true
    }
  }
};
