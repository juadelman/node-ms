const { makeAddComment } = require('./add.comment');
const { commentsDb } = require('../db');

// TODO: tenemos que definir este servicio.
const handleModeration = ({ comment }) => {
  comment.publish();
  return comment;
};

const addComment = makeAddComment({ commentsDb, handleModeration });

module.exports = Object.freeze({
  addComment
});
