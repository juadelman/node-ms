const { techLog } = require('@darwin-node/logger');
const { generate } = require('@darwin-node/composer');
const routes = require('../routers');
const darwinConfig = require('../config/darwin.config');
const app = generate(routes, darwinConfig);
const port = 3000;

app.listen(port, () => {
  techLog.info(`Clean architecture listening on: ${port}`);
});
