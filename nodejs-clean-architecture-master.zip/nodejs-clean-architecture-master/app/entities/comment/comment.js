const { AppError } = require('@darwin-node/error');
const makeHash = (md5) => (
  sanitizedText,
  published,
  author = '',
  postId = '',
  replyToId = ''
) => {
  return md5(`${sanitizedText}${published}${author}${postId}${replyToId}`);
};

const buildMakeComment = function ({ Id, md5, sanitize, makeSource }) {
  return function makeCommet ({
    author,
    createdOn = Date.now(),
    id = Id.makeId(),
    source,
    modifiedOn = Date.now(),
    postId,
    published = false,
    replyToId,
    text
  }) {
    if (!Id.isValidId(id)) {
      throw new AppError('bad_request', 400, 10000, 'Comment must have a valid id.', 'author empty');
    }
    if (!author) {
      throw new AppError('bad_request', 400, 10000, 'Comment must have an author.', 'author empty');
    }
    if (author.length < 2) {
      throw new AppError('bad_request', 400, 10000, 'Comment authors name must be longer than 2 characters.', '');
    }
    if (!postId) {
      throw new AppError('bad_request', 400, 10000, 'Comment must contain a postId.', '');
    }
    if (!text || text.length < 1) {
      throw new AppError('bad_request', 400, 10000, 'Comment must include at least one character of text.', '');
    }
    if (!source) {
      throw new AppError('bad_request', 400, 10000, 'Comment must have a source.', '');
    }
    if (replyToId && !Id.isValidId(replyToId)) {
      throw new AppError('bad_request', 400, 10000, 'If supplied. Comment must contain a valid replyToId.', '');
    }

    let sanitizedText = sanitize(text).trim();
    if (sanitizedText.length < 1) {
      throw new AppError('bad_request', 400, 10000, 'Comment contains no usable text.', '');
    }
    const validSource = makeSource(source);
    const deletedText = '.xX This comment has been deleted Xx.';
    let hash;
    return Object.freeze({
      getCreatedOn: () => createdOn,
      getAuthor: () => author,
      getCreated: () => createdOn,
      getHash: () => hash || (hash = makeHash(md5)(sanitizedText, published, author, postId, replyToId)),
      getId: () => id,
      getModifiedOn: () => modifiedOn,
      getPostId: () => postId,
      getReplyToId: () => replyToId,
      getSource: () => validSource,
      getText: () => sanitizedText,
      isDeleted: () => sanitizedText === deletedText,
      isPublished: () => published,
      markDeleted: () => {
        sanitizedText = deletedText;
        author = 'deleted';
      },
      publish: () => {
        published = true;
      },
      unPublish: () => {
        published = false;
      }
    });
  };
};

module.exports = {
  makeHash,
  buildMakeComment
};
