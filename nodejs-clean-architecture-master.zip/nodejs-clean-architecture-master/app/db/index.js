const { makeCommentsDb } = require('./comment');
const dotenv = require('dotenv');
dotenv.config();
const { MongoClient } = require('mongodb');
const url = process.env.DB_URL;
const dbName = process.env.DB_NAME;
const client = new MongoClient(url, {
  useNewUrlParser: true,
  username: 'fake_user',
  password: 'fake_pwd'
});

const makeDb = async function () {
  if (!client.isConnected()) {
    await client.connect();
  }
  return client.db(dbName);
};
const commentsDb = makeCommentsDb({ makeDb });
module.exports = {
  commentsDb,
  makeDb
};
