const { Id } = require('../../entities/id');
const makeCommentsDb = function ({ makeDb }) {
  return Object.freeze({
    insert,
    findByHash
  });
  async function insert ({ id: _id = Id.makeId(), commentInfo }) {
    const db = await makeDb();
    const result = await db
      .collection('comments')
      .insertOne({ _id, ...commentInfo });
    const { _id: id, ...insertedInfo } = result.ops[0];
    return { id, ...insertedInfo };
  };
  async function findByHash (comment) {
    const db = await makeDb();
    const result = await db
      .collection('comments')
      .find({ hash: comment.getHash() });
    const found = await result.toArray();
    if (found.length === 0) return null;
    const { _id: id, ...insertedInfo } = found[0];
    return { id, ...insertedInfo };
  };
};
module.exports = {
  makeCommentsDb
};
