const makePostComment = ({ addComment }) => {
  return async function postComment (req, res, next) {
    try {
      const { source = {}, ...commentInfo } = req.body;
      source.ip = req.ip;
      source.browse = req.headers['User-Agent'];
      if (req.headers.Referer) {
        source.referrer = req.headers.Referer;
      }
      const posted = await addComment({
        ...commentInfo,
        source
      });
      res.setHeader('Last-Modified', new Date(posted.modifiedOn).toUTCString());
      res.status(201).send(posted);
    } catch (e) {
      next(e);
    }
  };
};
module.exports = {
  makePostComment
};
