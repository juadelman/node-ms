const { makePostComment } = require('./comment');
const { addComment } = require('../services');
const postComent = makePostComment({ addComment });
const commentController = Object.freeze({
  postComent
});
module.exports = {
  commentController
};
