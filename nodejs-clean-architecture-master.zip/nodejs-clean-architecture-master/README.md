# NodeJs microservice using clean architecture.
It has been based on the following documentatio:
* [Using Clean Architecture for Microservice APIs in Node.js with Lowdb and Express](https://www.reddit.com/r/node/comments/dkqd9q/using_clean_architecture_for_microservice_apis_in/)
* [The Clean Architecture](https://blog.cleancoder.com/uncle-bob/2012/08/13/the-clean-architecture.html)

<p align="center">
  <img src="./images/CleanArchitecture.jpg" height="150" width="200">
  <br>
</p>

## 1. Entities
* Comments

## 2. Use Cases
* Create comment
* Edit comment
* Save comment
* Get comment
* Delete comment

```sh
oc port-forward mongodb-2-24k2s 9081:27017
```





