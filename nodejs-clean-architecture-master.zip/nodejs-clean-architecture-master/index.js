import dotenv from 'dotenv';
dotenv.config();
(async function setUpDb () {
  console.log('connectigt');
})();
