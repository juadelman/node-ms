const fn = require('../../src');

describe('**** UNIT TEST FOR SRC INDEX FILE ****', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it('it execute ', async (done) => {
    const inyectionLib = {
      execute: jest.fn().mockReturnValue(true)
    };
    fn(inyectionLib)('asdf');
    expect(inyectionLib.execute).toBeCalled();
    done();
  });
});
