const express = require('express');
const app = express();
const { techLog } = require('@darwin-node/logger');

app.get('/headers', (req, res, next) => {
  techLog.info('Headers');
  techLog.info(req.headers);
  res.send({ ...req.headers });
});

app.listen(3001, () => {
  techLog.info('starting appExample app listening on port 3001!');
});
