package com.santander.service.endpoints

import com.santander.core.common.{Common}
import com.santander.core.utils.{LoginKeycloak, SimulationCore}
import io.gatling.core.Predef._
import io.gatling.core.structure.ScenarioBuilder
import io.gatling.http.Predef._;

class ExampleTestPrivate extends SimulationCore("ExampleTestPrivate") with Common {
  /**
    * Gets the feeder file name.
    *
    * @return String
    */
  def getFeederFileName(): String = {
    "local-exampleData.csv"
  }

  /**
    * Gets the session Heades
    *
    * @return Map[String, String]
    */
  def getSessionHeaders(token: String): Map[String, String] = {
    Map("Authorization" -> s"Bearer ${token}", "Content-Type" -> "application/json");
  }

  /**
    * Gets data to the http data
    *
    * @return String
    */
  def getDataString(): String = {
    """${parameters}""";
  }

  /**
    * Gets the valid response codes.
    *
    * @return
    */
  def getValidResponseCodes(): Seq[Int] = {
    Seq();
  }

  /**
    * Gets service extend url
    *
    * @return String
    */
  def getServiceUrl(): String = {
    "/private/api/example?parameter="
  }

  /**
    * Builds an scenario to inject.
    *
    * @return ScenarioBuilder
    */
  def buildScenario(): ScenarioBuilder = {
    val feeder = csv(getFeederFileName()).circular;
    val token = LoginKeycloak.loginKeycloak();
    val sessionHeaders = getSessionHeaders(token);
    val scenarioName = getScenarioName();
    val execution = exec(
      http(scenarioName)
        .get(getServiceUrl().concat(getDataString()))
        .headers(sessionHeaders)
        .check(status.in(200, 400, 404))
    );
    val scn = scenario(scenarioName)
      .feed(feeder)
      .exec(execution);
    return scn;
  }
}
