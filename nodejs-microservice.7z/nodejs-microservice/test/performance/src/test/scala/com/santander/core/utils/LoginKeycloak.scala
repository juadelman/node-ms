package com.santander.core.utils

import com.google.gson.{Gson, JsonObject}
import com.santander.core.common.Common
import scalaj.http.{Http, HttpOptions}

object LoginKeycloak extends App with Common {

  def loginKeycloak(user: String = KEYCLOAK_USER, pwd: String = KEYCLOAK_PWD): String = {
    case class LoginResponse(access_token: String, red: Int, green: Int, blue: Int);
    val result = Http(KEYCLOAK_LOGIN_URL)
      .postForm
      .param("username", user)
      .param("password", pwd)
      .param("grant_type", "password")
      .param("client_id", CLIENT_ID)
      .header("Content-Type", "application/json")
      .header("Charset", "UTF-8")
      .option(HttpOptions.readTimeout(10000)).asString;
    new Gson().fromJson(result.body, classOf[JsonObject]).get("access_token").getAsString;
  }
}
