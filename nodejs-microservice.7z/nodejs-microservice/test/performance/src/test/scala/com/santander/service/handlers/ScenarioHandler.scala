package com.santander.service.handlers

import io.gatling.core.scenario.Simulation
import io.gatling.core.Predef._
import com.santander.core.common.Common
import com.santander.service.endpoints.{ExampleTestPrivate, ExampleTestPublic}
import io.gatling.http.Predef.http;

class ScenarioHandler extends Simulation with Common {


  val exampleTest = new ExampleTestPublic();
  val scn0 = exampleTest.buildScenario();

  val exampleTestPrivate = new ExampleTestPrivate();
  val scn1 =  exampleTestPrivate.buildScenario();
  // setUpScenario
  setUp(
    scn0.inject(
      constantUsersPerSec(CONCURRENTUSERS) during (TEST_SECONDS),
    ),
    scn1.inject(
      constantUsersPerSec(CONCURRENTUSERS) during (TEST_SECONDS),
    )
  ).protocols(
    http
      .baseURL("http://localhost:3002") // TODO: REPLACE
      // .baseURL(serviceUrl)   //  TODO: UNCOMMENTED THIS
      .acceptHeader("*/*")
      .acceptEncodingHeader("gzip, deflate")
      .acceptLanguageHeader("es-ES,es;q=0.8,en-US;q=0.5,en;q=0.3")
      .userAgentHeader("Mozilla/5.0 (Macintosh; Intel Mac OS X 10.13; rv:62.0) Gecko/20100101 Firefox/62.0")
      .disableWarmUp
  );
}
