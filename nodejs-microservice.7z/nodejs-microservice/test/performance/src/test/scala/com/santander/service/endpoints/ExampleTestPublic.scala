package com.santander.service.endpoints

import com.santander.core.common.Common
import com.santander.core.utils.SimulationCore
import io.gatling.core.Predef._
import io.gatling.core.structure.ScenarioBuilder
import io.gatling.http.Predef._;

class ExampleTestPublic extends SimulationCore("ExampleTest") with Common{
  /**
    * Gets the feeder file name.
    *
    * @return String
    */
  def getFeederFileName(): String = {
    "local-exampleData.csv"
  }

  /**
    * Gets the session Heades
    *
    * @return Map[String, String]
    */
  def getSessionHeaders(token: String): Map[String, String] = {
    Map();
  }

  /**
    * Gets data to the http data
    *
    * @return String
    */
  def getDataString(): String = {
    """${parameters}""";
  }

  /**
    * Gets the valid response codes.
    *
    * @return
    */
  def getValidResponseCodes(): Seq[Int] = {
    Seq();
  }

  /**
    * Gets service extend url
    *
    * @return String
    */
  def getServiceUrl(): String = {
    "/public/api/example?parameter="
  }

  /**
    * Builds an scenario to inject.
    *
    * @return ScenarioBuilder
    */
  def buildScenario(): ScenarioBuilder = {
    val feeder = csv(getFeederFileName()).circular;
    val scenarioName = getScenarioName();
    val execution = exec(
      http(scenarioName)
        .get(getServiceUrl().concat(getDataString()))
        .check(status.in(200, 400, 404))
    );
    val scn = scenario(scenarioName)
      .feed(feeder)
      .exec(execution);
    return scn;
  }
}
