package com.santander.core.utils;

import io.gatling.core.structure.{ScenarioBuilder};

abstract class SimulationCore(name: String) {
  /**
    * Get the name of class
    * @return String
    */
  def getName(): String = {
    return name;
  }

  /**
    * Returns the scenario name
    * @return
    */
  def getScenarioName(): String ={
    val prefix : String = "Scn ";
    return prefix.concat(this.name);
  }

  /**
    * Gets the feeder file name.
    * @return String
    */
  def getFeederFileName(): String;

  /**
    * Gets the session Heades
    * @return Map[String, String]
    */
  def getSessionHeaders(token: String): Map[String, String];

  /**
    * Gets data to the http data
    * @return String
    */
  def getDataString(): String;

  /**
    * Gets the valid response codes.
    * @return
    */
  def getValidResponseCodes(): Seq[Int];

  /**
    * Gets service extend url
    * @return String
    */
  def getServiceUrl(): String;

  /**
    * Builds an scenario to inject.
    * @return ScenarioBuilder
    */
  def buildScenario(): ScenarioBuilder;

}
