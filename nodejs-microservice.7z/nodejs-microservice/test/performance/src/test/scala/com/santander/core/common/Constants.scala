package com.santander.core.common

trait Constants {

  /* Api manager configuration */
  final val DEFAULT_ENVIROMENT = "pre";
  final val PROTOCOL = "https://";
  final val UNIVERSIA_DOMAIN = "universia.com";
  final val API_MANAGER_PREFIX = "https://api-manager.";
  final val API_MANAGER_SUFIX = ".universia.net";
  final val SSO_PREFIX = "https://sso.";
  final val SSO_SUFIX = ".universia.net";

  /* Keycloak configuration*/
  final val KEYCLOAK_LOGIN_PREFIX = "https://sso.";
  final val KEYCLOAK_LOGIN_SUFIX = ".universia.net/auth/realms/CorePlatform/protocol/openid-connect/token";
  final val KEYCLOAK_LOGIN_URL = KEYCLOAK_LOGIN_PREFIX.concat(System.getProperty("env")).concat(KEYCLOAK_LOGIN_SUFIX);
  final val KEYCLOAK_USER = "alexis.cumbal@kairosds.com";
  final val KEYCLOAK_PWD = "123Asdw33dklkj";
  final val CLIENT_ID = "core-landing";
  /* Service configuration*/
  final val SERVICE_URL = ""; // TODO: Define it.

  /* Simulation constants */
  final val INJECT_DURATION = "1";
  final val N_MAX_DURATION = "5";
  final val MAX_RESP_TIME = "1";
  final val OVER_DURATION = "10";
  final val N_SEPARATED_BY = "1";
  final val REQ_PERCENTAGE = "100";
  final val USERS = "1";
  final val CONCURRENTUSERS = 2;
  final val TEST_SECONDS = 60;

  
  
}
