package com.santander.core.common

trait Common extends Constants {
  /* Enviroment configuration */
  val env = System.getProperty("env", DEFAULT_ENVIROMENT);
  val apiMngBaseURL = System.getProperty("apiMngBaseURL", API_MANAGER_PREFIX
    .concat(env).concat(API_MANAGER_SUFIX));
  val serviceUrl = apiMngBaseURL.concat(SERVICE_URL);
  val ssoUlr = System.getProperty("ssoUrl", SSO_PREFIX.concat(env).concat(SSO_SUFIX));

  /* Simulation config */
  try {
    val users = Integer.parseInt(System.getProperty("users", USERS));
    val injectionDuration = Integer.parseInt(System.getProperty("adf", INJECT_DURATION));
    val nMmaxDuration = Integer.parseInt(System.getProperty("maxDuration", N_MAX_DURATION));
    val maxResponseTime = Integer.parseInt(System.getProperty("maxResponseTime", MAX_RESP_TIME));
    val overDuration = Integer.parseInt(System.getProperty("overDuration", OVER_DURATION));
    val nseparatedBy = Integer.parseInt(System.getProperty("separatedBy", N_SEPARATED_BY));
    val requestPercentage = Integer.parseInt(System.getProperty("rPercent", REQ_PERCENTAGE));
  } catch {
    case e: Exception => {
      e.printStackTrace();
      System.exit(1);
    }
  }

  /* Define functions to be extended in other clases */
  def getStartingMessage(requestName: String) = requestName.concat(" test is about to start for ")
    .concat(" --SERVICE NAME-- ").concat(" in ").concat(env).toUpperCase;
  def getEndingMessage(requestName: String) = requestName.concat(" test is finished for ")
    .concat(" --SERVICE NAME-- ").concat(" in ").concat(env).toUpperCase;

}
