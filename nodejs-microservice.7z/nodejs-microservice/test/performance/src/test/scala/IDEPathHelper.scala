import java.nio.file.Path;
import io.gatling.commons.util.PathHelper._;

object IDEPathHelper {

  /* setting gatling config */
  val gatlingConfigUrl: Path = getClass.getClassLoader.getResource("gatling.conf");
  val projectRootDir = gatlingConfigUrl.ancestor(3);

  // define directories
  val projectScalaDir = projectRootDir /"src"/"test"/"scala";
  val projectResourcesDir = projectRootDir /"src"/"test"/"resources";
  val projectTargetDir = projectRootDir /"target";

  val dataDir = projectResourcesDir /"data";
  val bodiesDir = projectResourcesDir /"bodies";

  val recorderOutputDir = projectScalaDir;
  val resultsDir = projectTargetDir /"gatling";

  val recorderConfigFile = projectResourcesDir /"recorder.conf";

}
