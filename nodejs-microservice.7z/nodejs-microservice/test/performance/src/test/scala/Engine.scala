import io.gatling.core.config.GatlingPropertiesBuilder;

object Engine extends App {

  new GatlingPropertiesBuilder().dataDirectory(IDEPathHelper.dataDir.toString);

}
