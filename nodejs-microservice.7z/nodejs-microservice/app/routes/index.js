const pocRoute = require('./poc.route');
const express = require('express');
const router = express.Router();

router.use('/api/poc', pocRoute);

module.exports = router;
