const express = require('express');
const pocController = require('../controllers/poc.controller');
const router = express.Router();

router.route('/cats/:catId([0-9]{6})')
  .get(pocController.getAllCats);

router.route(/\/domain\/.*\/cancel/)
  .put(pocController.cancel);

router.route('/error')
  .get(pocController.error);

router.route('/only/put')
  .put(pocController.onlyMethodPut);

router.route('/secure/route')
  .get(pocController.secureRoute);

module.exports = router;
