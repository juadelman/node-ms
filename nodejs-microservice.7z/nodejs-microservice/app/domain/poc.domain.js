const fakeDomainFunc = (
  log
) => (data) => {
  log.info('fakeDomainFunc');
  log.info('Data');
  log.info(data);
  return data;
};
const testHeadersPropagation = (
  log,
  axios
) => async (url) => {
  log.info('testing headers propagation');
  log.info(`Request to: ${url}`);
  let resp;
  try {
    resp = await axios.get(url);
  } catch (err) {
    resp = { ...err };
  }
  return resp;
};

module.exports = {
  fakeDomainFunc,
  testHeadersPropagation
};
