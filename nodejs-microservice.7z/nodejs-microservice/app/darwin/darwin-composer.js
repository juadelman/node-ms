const express = require('express');
const app = express();
const debug = require('debug');
const log = debug('darwin:composer');
const { reqCntxMiddleware, overrideResponse } = require('darwin-middlewares');
const contextService = require('request-context');
const jwtSecurity = require('darwin-express-security');
const { errorHandler } = require('darwin-error');

const generate = (routes, opts) => {
  log('generating darwin app');

  log('setting override res.send to activity log');
  app.use(overrideResponse);

  log('setting request context');
  app.use(contextService.middleware('request'));
  app.use(reqCntxMiddleware);

  log('setting security');
  if (opts.security.enable) {
    jwtSecurity.init(opts.security);
    app.use(jwtSecurity.middleware);
  }

  log('setting application routes');
  app.use(routes);

  log('setting error handler as last middleware');
  app.use(errorHandler);

  return app;
};

module.exports = {
  generate
};
