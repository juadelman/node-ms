const pocDomain = require('../domain/poc.domain');
const { techLog } = require('@darwin-node/logger');
const { AppError } = require('@darwin-node/error');
const axios = require('axios');

const getAllCats = async (req, res, next) => {
  const respData = pocDomain.fakeDomainFunc(techLog)(['cat1', 'cat2', 'cat3']);
  res.status(200).send({
    pathType: 'public mapping',
    respData
  });
};

const cancel = (req, res, next) => {
  const respData = pocDomain.fakeDomainFunc(
    techLog
  )({ pocId: 'fakeId', status: 'cancelled' });
  res.status(200).send({
    pathType: 'route with regexp',
    respData
  });
};
const error = (req, res, next) => {
  next(new AppError('error', 403, 1000, 'Short message', 'Detailed Message', {
    extend: {
      whateveryouwant: {
        key: 1,
        key2: 2
      }
    }
  }));
};
const onlyMethodPut = (req, res, next) => {
  const respData = pocDomain.fakeDomainFunc(
    techLog
  )({
    method: 'put',
    exclude: ['POST', 'GET', 'PATCH', 'ETC']
  });
  res.status(200).send({
    pathType: 'public route only method put allowed',
    respData
  });
};
const secureRoute = async (req, res, next) => {
  const respData = await pocDomain.testHeadersPropagation(
    techLog,
    axios
  )('http://127.0.0.1:3001/headers');
  res.status(200).send({
    pathType: 'secure route, testing headers',
    headersPropagated: respData.data
  });
};
module.exports = {
  getAllCats,
  cancel,
  error,
  onlyMethodPut,
  secureRoute
};
